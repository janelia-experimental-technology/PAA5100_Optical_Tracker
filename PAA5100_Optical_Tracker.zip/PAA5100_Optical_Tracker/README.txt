An Arduino library to interface with the PAA5100JE near optical flow tracking sensor.

The example sketch provided is used to determine the orientation of a spherical tradmill by tracking the changes to the X and Y coordinates. The position data is intented to be sent via USB.

